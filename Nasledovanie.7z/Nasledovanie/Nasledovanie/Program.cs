﻿using figures;

Geometry_figure Kvadrat=new Square(3.25);       //Создаем объект квадрата с данными и выводим его на экран
Kvadrat.Print();

Geometry_figure Treugolnik = new Triangle(6.75, 6.5, 9);        //Создаем объект треугольника с данными и выводим его на экран
Treugolnik.Print();

Geometry_figure Krug = new Circle(5.5);         //Создаем объект круга с данными и выводим его на экран
Krug.Print();

Geometry_figure Pryamougolnik = new Rectangle(3.6,6.5);       //Создаем объект прямоугольник с данными и выводим его на экран
Pryamougolnik.Print();
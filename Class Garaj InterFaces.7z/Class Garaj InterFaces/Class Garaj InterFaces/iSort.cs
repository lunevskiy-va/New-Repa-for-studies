﻿
namespace Class_Garaj_InterFaces
{
    public interface iSort

    {
    
        void SortName();
        void SortColor();
        void SortSpeed();
    }
}

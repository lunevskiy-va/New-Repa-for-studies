﻿

namespace Animal
{
    internal interface Imesto
    {
        string Place_leave { get; set; }
        string Production { get; set; }

    }
}

﻿
namespace Animal
{
    public interface Idom
    {
        string Opisanie { get; set; }
        string Master { get; set; }

    }
}

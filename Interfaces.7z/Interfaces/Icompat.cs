﻿

namespace Animal
{
    public interface Icompat
    {
        bool IsComp { get; }
        string NameAnimal();
        string Voice();
    }
}
